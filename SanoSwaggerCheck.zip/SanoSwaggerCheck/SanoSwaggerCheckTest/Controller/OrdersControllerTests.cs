﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;
using FluentAssertions;
using SanoSwaggerCheck.Controllers;
using SanoSwaggerCheck.Entities;
using SanoSwaggerCheck.Repositories;
using Microsoft.Extensions.Logging;
using SanoSwaggerCheck.Requests;

namespace SanoSwaggerCheck.Tests
{
    public class OrdersControllerTests
    {
        private readonly Mock<IOrderRepository> _orderRepositoryMock;
        private readonly Mock<ILogger<OrdersController>> _loggerMock;
        private readonly OrdersController _controller;

        public OrdersControllerTests()
        {
            _orderRepositoryMock = new Mock<IOrderRepository>();
            _loggerMock = new Mock<ILogger<OrdersController>>();
            _controller = new OrdersController(_orderRepositoryMock.Object, _loggerMock.Object);
        }

        // Test for GetRecentOrders
        [Fact]
        public async Task GetRecentOrders_ShouldReturnOk_WithOrderList()
        {
            // Arrange
            var mockOrders = new List<Order>
            {
                new Order { Id = Guid.NewGuid(), Name = "Order1", Description = "Description1" },
                new Order { Id = Guid.NewGuid(), Name = "Order2", Description = "Description2" }
            };
            _orderRepositoryMock.Setup(repo => repo.GetRecentOrders()).ReturnsAsync(mockOrders);

            // Act
            var result = await _controller.GetRecentOrders();

            // Assert
            var okResult = result.Result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult.StatusCode.Should().Be(200);
            var returnedOrders = okResult.Value as List<Order>;
            returnedOrders.Should().BeEquivalentTo(mockOrders);
        }

        // Test for CreateOrder with valid request
        [Fact]
        public async Task CreateOrder_ValidRequest_ShouldReturnCreatedOrder()
        {
            // Arrange
            var createRequest = new CreateOrderRequest { Name = "New Order", Description = "New Description" };
            var createdOrder = new Order { Id = Guid.NewGuid(), Name = createRequest.Name, Description = createRequest.Description };

            _orderRepositoryMock.Setup(repo => repo.AddNewOrder(It.IsAny<Order>()))
                .ReturnsAsync(createdOrder);

            // Act
            var result = await _controller.CreateOrder(createRequest);

            // Assert
            var createdAtActionResult = result.Result as CreatedAtActionResult;
            createdAtActionResult.Should().NotBeNull();
            createdAtActionResult.StatusCode.Should().Be(201);
            var returnedOrder = createdAtActionResult.Value as Order;
            returnedOrder.Should().BeEquivalentTo(createdOrder);
        }

        // Test for CreateOrder with invalid request
        [Fact]
        public async Task CreateOrder_InvalidRequest_ShouldReturnBadRequest()
        {
            // Arrange
            _controller.ModelState.AddModelError("Name", "Name is required");

            var invalidRequest = new CreateOrderRequest { Description = "Description without Name" };

            // Act
            var result = await _controller.CreateOrder(invalidRequest);

            // Assert
            var badRequestResult = result.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            badRequestResult.StatusCode.Should().Be(400);
        }
    }
}
