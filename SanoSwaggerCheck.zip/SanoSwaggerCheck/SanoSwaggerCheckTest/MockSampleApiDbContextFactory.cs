﻿using Microsoft.EntityFrameworkCore;
using SanoSwaggerCheck.Entities;
using System.Linq;
using Xunit;

namespace SanoSwaggerCheck.Tests
{
    public class SampleApiDbContextTests
    {
        private SampleApiDbContext GetInMemoryDbContext()
        {
            var options = new DbContextOptionsBuilder<SampleApiDbContext>()
                .UseInMemoryDatabase("SampleApiTestDb")
                .Options;

            var context = new SampleApiDbContext(options);
            return context;
        }

        [Fact]
        public void AddOrder_SavesToInMemoryDatabase()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            var order = new Order { Name = "Test Order", Description = "Test Description" };

            // Act
            context.Orders.Add(order);
            context.SaveChanges();

            // Assert
            Assert.Equal(1, context.Orders.Count()); // Ensure one order is added
            Assert.Equal("Test Order", context.Orders.First().Name);
        }
    }
}
