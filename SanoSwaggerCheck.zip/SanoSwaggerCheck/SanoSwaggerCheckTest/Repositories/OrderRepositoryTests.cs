﻿using Microsoft.EntityFrameworkCore;
using SanoSwaggerCheck.Entities;
using SanoSwaggerCheck.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace SanoSwaggerCheck.Tests.Repositories
{
    public class OrderRepositoryTests
    {
        private SampleApiDbContext GetDbContext()
        {
            var options = new DbContextOptionsBuilder<SampleApiDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Use in-memory database
                .Options;

            var context = new SampleApiDbContext(options);
            context.Database.EnsureCreated();  // Ensure the database is created
            return context;
        }

        [Fact]
        public async Task GetRecentOrders_ReturnsOrdersFromLastDay()
        {
            // Arrange
            var context = GetDbContext();
            var repository = new OrderRepository(context);

            // Seed data
            var orders = new List<Order>
            {
                new Order { Id = Guid.NewGuid(), Name = "Old Order", Description = "Desc1", EntryDate = DateTime.UtcNow.AddDays(-2), IsDeleted = false },
                new Order { Id = Guid.NewGuid(), Name = "Recent Order", Description = "Desc2", EntryDate = DateTime.UtcNow.AddHours(-6), IsDeleted = false },
                new Order { Id = Guid.NewGuid(), Name = "Deleted Order", Description = "Desc3", EntryDate = DateTime.UtcNow.AddHours(-4), IsDeleted = true }
            };

            await context.Orders.AddRangeAsync(orders);
            await context.SaveChangesAsync();

            // Act
            var result = await repository.GetRecentOrders();

            // Assert
            Assert.Single(result);  // Only one non-deleted order in the last 24 hours
            Assert.Equal("Recent Order", result.First().Name);  // Check the correct order is returned
        }

        [Fact]
        public async Task AddNewOrder_SavesOrderAndReturnsIt()
        {
            // Arrange
            var context = GetDbContext();
            var repository = new OrderRepository(context);

            var newOrder = new Order
            {
                Name = "Test Order",
                Description = "Test Description"
            };

            // Act
            var result = await repository.AddNewOrder(newOrder);

            // Assert
            Assert.NotNull(result); // Ensure the result is not null
            Assert.NotEqual(Guid.Empty, result.Id); // Ensure an ID is generated
            Assert.Equal("Test Order", result.Name); // Ensure the Name is correct
            Assert.Equal("Test Description", result.Description); // Ensure the Description is correct
            Assert.True((DateTime.UtcNow - result.EntryDate).TotalSeconds < 1); // Ensure EntryDate is set to current time

            // Verify that the order was actually saved in the database
            var savedOrder = await context.Orders.FirstOrDefaultAsync(o => o.Id == result.Id);
            Assert.NotNull(savedOrder);  // Ensure the order is saved in the DB
        }
    }
}
