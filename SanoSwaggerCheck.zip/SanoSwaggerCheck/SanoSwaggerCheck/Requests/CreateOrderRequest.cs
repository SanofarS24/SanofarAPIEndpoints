﻿using System.ComponentModel.DataAnnotations;

namespace SanoSwaggerCheck.Requests
{
    public class CreateOrderRequest
    {
        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        [Required]
        [StringLength(100)]
        public string Description { get; set; }
    }
}
