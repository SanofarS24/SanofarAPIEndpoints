﻿using Microsoft.EntityFrameworkCore;
using SanoSwaggerCheck.Entities;
using System.Collections.Generic;

namespace SanoSwaggerCheck.Entities 
{
    public class SampleApiDbContext : DbContext
    {
        public SampleApiDbContext(DbContextOptions<SampleApiDbContext> options) : base(options) { }

        // DbSets for your entities
        public DbSet<Order> Orders { get; set; }
    }
}
