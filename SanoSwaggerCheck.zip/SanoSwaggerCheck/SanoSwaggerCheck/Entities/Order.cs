﻿using System;
using System.ComponentModel.DataAnnotations;

namespace SanoSwaggerCheck.Entities
{
    public class Order
    {
        [Key] // This makes Id the primary key.
        public Guid Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; }

        [Required]
        [MaxLength(100)]
        public string Description { get; set; }

        [Required]
        public DateTime EntryDate { get; set; }

        // Default to true - The order has been invoiced
        public bool IsInvoiced { get; set; } = true;

        // Default to false - The order is not deleted
        public bool IsDeleted { get; set; } = false;
    }
}
