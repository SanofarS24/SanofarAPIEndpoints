﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SanoSwaggerCheck.Entities;
using SanoSwaggerCheck.Repositories;
using SanoSwaggerCheck.Requests;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SanoSwaggerCheck.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrdersController : ControllerBase
    {
        private readonly IOrderRepository _orderRepository;
        private readonly ILogger<OrdersController> _logger;

        public OrdersController(IOrderRepository orderRepository, ILogger<OrdersController> logger)
        {
            _orderRepository = orderRepository;
            _logger = logger;
        }

        // GET: api/orders
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<List<Order>>> GetRecentOrders()
        {
            var orders = await _orderRepository.GetRecentOrders();
            return Ok(orders);
        }

        // POST: api/orders
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<Order>> CreateOrder([FromBody] CreateOrderRequest request)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var order = new Order
            {
                Name = request.Name,
                Description = request.Description
            };

            var createdOrder = await _orderRepository.AddNewOrder(order);
            return CreatedAtAction(nameof(GetRecentOrders), new { id = createdOrder.Id }, createdOrder);
        }
    }
}
