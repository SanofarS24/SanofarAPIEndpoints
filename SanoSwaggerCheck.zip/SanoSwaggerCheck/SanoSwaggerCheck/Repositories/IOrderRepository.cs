﻿using SanoSwaggerCheck.Entities;
using SanoSwaggerCheck.Requests;

namespace SanoSwaggerCheck.Repositories
{
    public interface IOrderRepository
    {
        // Method to retrieve recent orders (orders from the last 24 hours and not deleted)
        Task<List<Order>> GetRecentOrders();

        // Method to add a new order
        Task<Order> AddNewOrder(Order order);
    }
}
