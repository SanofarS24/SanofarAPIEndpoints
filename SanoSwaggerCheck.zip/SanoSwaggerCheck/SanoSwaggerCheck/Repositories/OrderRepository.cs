﻿using SanoSwaggerCheck.Entities;
using Microsoft.EntityFrameworkCore;

namespace SanoSwaggerCheck.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private readonly SampleApiDbContext _context; 

        public OrderRepository(SampleApiDbContext context) 
        {
            _context = context;
        }

        // Get recent orders
        public async Task<List<Order>> GetRecentOrders()
        {
            return await _context.Orders
                .Where(o => o.EntryDate >= DateTime.UtcNow.AddDays(-1) && !o.IsDeleted)
                .OrderByDescending(o => o.EntryDate)
                .ToListAsync();

        }

        // Add a new order
        public async Task<Order> AddNewOrder(Order order)
        {
            order.Id = Guid.NewGuid();
            order.EntryDate = DateTime.UtcNow;

            _context.Orders.Add(order);
            await _context.SaveChangesAsync();
            return order;
        }
    }
}
